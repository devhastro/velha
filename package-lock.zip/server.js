const express = require("express");
const http = require("http");
const os = require("os");
const path = require("path");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 3000;
const HOST = "0.0.0.0";

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" },
});

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (_req, res) => {
  res.redirect("/jogo_da_velha_multinivel.html");
});

let players = { X: "", O: "" };
const slots = { X: null, O: null };

function getPlayersPayload() {
  return { X: players.X, O: players.O };
}

function roleForSocket(socketId) {
  if (slots.X === socketId) return "X";
  if (slots.O === socketId) return "O";
  return null;
}

function availableRole() {
  if (!slots.X) return "X";
  if (!slots.O) return "O";
  return null;
}

function getLanAddresses() {
  const addresses = [];
  for (const interfaces of Object.values(os.networkInterfaces())) {
    for (const net of interfaces) {
      const isIPv4 = net.family === "IPv4" || net.family === 4;
      if (isIPv4 && !net.internal) {
        addresses.push(net.address);
      }
    }
  }
  return addresses;
}

function releaseSlot(socket) {
  const role = roleForSocket(socket.id);
  if (!role) return;

  if (slots[role] === socket.id) slots[role] = null;
  players[role] = "";
  socket.pendingRole = null;
  socket.assignedRole = null;
  io.emit("playersUpdate", getPlayersPayload());
}

io.on("connection", (socket) => {
  const role = availableRole();
  if (!role) {
    socket.emit("roomFull");
    socket.emit("playersUpdate", getPlayersPayload());
    return;
  }

  slots[role] = socket.id;
  socket.pendingRole = role;
  socket.emit("joinPrompt", { role });
  socket.emit("playersUpdate", getPlayersPayload());

  socket.on("joinWithName", (data) => {
    const role = socket.pendingRole || roleForSocket(socket.id);
    if (!role || slots[role] !== socket.id) {
      socket.emit("joinError", { message: "Não foi possível entrar. Tente recarregar a página." });
      return;
    }

    const name = String(data.name || "").trim().slice(0, 24);
    if (!name) {
      socket.emit("joinError", { message: "Digite um nome para entrar." });
      return;
    }

    if (data.role && data.role !== role) {
      socket.emit("joinError", { message: "Vaga inválida. Recarregue a página." });
      return;
    }

    players[role] = name;
    socket.pendingRole = null;
    socket.assignedRole = role;

    socket.emit("playerAssigned", role);
    io.emit("playersUpdate", getPlayersPayload());
  });

  socket.on("playMove", (data) => {
    socket.broadcast.emit("playMove", data);
  });

  socket.on("startGame", (data) => {
    socket.broadcast.emit("startGame", data);
  });

  socket.on("restartGame", (data) => {
    socket.broadcast.emit("restartGame", data);
  });

  socket.on("disconnect", () => {
    releaseSlot(socket);
  });
});

server.listen(PORT, HOST, () => {
  console.log(`\nServidor rodando na porta ${PORT}`);
  console.log(`\n  Neste PC:  http://localhost:${PORT}/`);
  const lan = getLanAddresses();
  if (lan.length) {
    console.log("\n  Na rede LAN (outros dispositivos):");
    for (const ip of lan) {
      console.log(`    http://${ip}:${PORT}/`);
    }
  } else {
    console.log("\n  (Nenhum IP de LAN detectado — verifique Wi-Fi/cabo.)");
  }
  console.log(
    "\n  1º jogador: nome → X | 2º jogador: nome → O | 3º: sala lotada\n"
  );
});
